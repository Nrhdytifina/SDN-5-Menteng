<?php
$host = 'localhost'; // Nama hostnya
$username = 'root'; // Username
$password = ''; // Password (Isi jika menggunakan password)
$database = 'mynotescode2'; // Nama databasenya
$base_url = 'http://localhost/login_role_php/'; // Set Base UrlnWeb
// Koneksi ke MySQL dengan PDO
$pdo = new PDO('mysql:host='.$host.';dbname='.$database,
$username, $password);
?>