
<div class="container-fluid">
    <ol class="breadcrumb">
        <li><a href="#!">root</a></li>
        <li><a href="#!">Home</a></li>
    </ol>

    <div class="jumbotron">
        <h1>Selamat datang</h1>
        <p>Disini anda bisa memasukkan data siswa, menyunting data, dan menghapus data.</p>
        <p><a href="index.php?p=viewData" class="btn btn-primary btn-lg">Lihat Data</a></p>
    </div>
</div>

<script type="text/javascript">
    $('.li-home').addClass('active');
</script>