<div class="container-fluid">
    <ol class="breadcrumb">
        <li><a href="#!">root</a></li>
        <li><a href="#!">About</a></li>
    </ol>

    <h1>About</h1><br>

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde nemo porro rem quam! Maxime laboriosam pariatur repudiandae necessitatibus reiciendis libero delectus. Nemo reiciendis, nesciunt soluta optio molestiae cumque aliquid praesentium.</p>
</div>
<script type="text/javascript">
    $('.li-about').addClass('active');
</script>