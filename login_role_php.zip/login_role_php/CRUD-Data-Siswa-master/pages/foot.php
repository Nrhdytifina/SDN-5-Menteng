<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/angular/angular.min.js"></script>
</body>

<!-- <footer style="">
    <div class="well" style="position:absolute;left:0;bottom:0;right:0;margin-bottom:0;padding-top:50px;">
        <p class="text-center"style="line-height:100%;margin-bottom:-2px;">Copyright &copy; <a href="#!">Muhammad Yusup</a> 2018</p>
    </div>
</footer> -->

</html>