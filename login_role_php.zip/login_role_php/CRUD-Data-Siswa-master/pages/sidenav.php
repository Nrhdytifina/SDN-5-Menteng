<div class="container-fluid">
    <p style="font-weight:bold;color:#777;">Side navbar</p>

    <ul class="nav nav-pills nav-stacked">
        <li role="presentation" class="li-home"><a href="index.php?p=home">Home </a></li>
        <li role="presentation" class="li-view"><a href="index.php?p=viewData">View Data</a></li>
        <li role="presentation" class="li-insert"><a href="index.php?p=insertData">Insert Data</a></li>
        <li role="presentation" class="li-update"><a href="index.php?p=updateData">Update Data</a></li>
        <li role="presentation" class="li-about"><a href="index.php?p=about">About</a></li>
    </ul>
</div>