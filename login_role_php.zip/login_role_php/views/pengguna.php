<div class="pull-right">
<a href="" class="btn btn-success">TAMBAH DATA</a>
</div>
<h2 style="margin-top: 0;margin-bottom: 0;">Pengguna</h2>
<div class="clearfix"></div>
<hr />
<div class="table-responsive">
<table class="table table-bordered table-hover">
<thead>
<tr>
<th>No</th>
<th>Username</th>
<th>Nama</th>
<th>Role</th>
<th style="width: 80px;">Aksi</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>rizaldi</td>
<td>Rizaldi Maulidia Achmad</td>
<td>Admin</td>
<td>
<a href="" class="btn btn-default btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
<a href="" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
</td>
</tr>
<tr>
<td>2</td>
<td>Siska</td>
<td>siska Melina Rachman</td>
<td>Operator</td>
<td>
<a href="" class="btn btn-default btn-xs"><i class="glyphicon glyphicon-pencil"></i></a>
<a href="" class="btn btn-danger btn-xs"><i class="glyphicon glyphicon-trash"></i></a>
</td>
</tr>
</tbody>
</table>
</div>